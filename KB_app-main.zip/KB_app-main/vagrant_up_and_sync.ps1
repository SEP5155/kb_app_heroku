vagrant up

vagrant rsync-auto